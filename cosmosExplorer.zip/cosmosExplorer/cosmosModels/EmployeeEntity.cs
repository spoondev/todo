﻿using System;

using Microsoft.Azure.Cosmos;
using Microsoft.Azure.Cosmos.Table;

namespace cosmosModels
{
    public class EmployeeEntity : TableEntity
    {
        public EmployeeEntity()
        {
        }

        //first few lines need a look at
        public EmployeeEntity(string domainQualifiedUsername, string Rowkey)
        {
            string PartitionKey = domainQualifiedUsername;
            //RowKey = RowKey;
        }

        public string BusinessArea { get; set; }
        public string CreatedBy { get; set; }
        public string Email { get; set; }
        public string EmployeeFirst { get; set; }
        public string EmployeeLast { get; set; }
        public int EmployeeNumber { get; set; }
        public bool Leaver { get; set; }
        public int ManagerID { get; set; }
        public string ModifiedBy { get; set; }
        public DateTime ModifiedDate { get; set; }
        public int UserRoleID { get; set; }


        internal static FeedIterator<T> GetItemQueryIterator<T>(QueryDefinition queryDefinition)
        {
            throw new NotImplementedException();
        }
    }

}
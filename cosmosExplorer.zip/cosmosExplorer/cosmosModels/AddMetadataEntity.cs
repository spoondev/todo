﻿using System;

using Microsoft.Azure.Cosmos;
using Microsoft.Azure.Cosmos.Table;
//using Microsoft.WindowsAzure.Storage.Table;

namespace cosmosModels

{

    public class AddMetadataEntity : TableEntity

    {

        public AddMetadataEntity()

        {

        }



        public AddMetadataEntity(string Volume, string RowKey)

        {

            string PartitionKey = Volume;

            //RowKey = RowKey;

        }



        public int AmID { get; set; }

        public DateTime AccessedDate { get; set; }

        public int ApprovalStatus { get; set; }

        public string Author { get; set; }

        public string AuthorAccount { get; set; }

        public string Category { get; set; }

        public string CheckedOutTo { get; set; }

        public string ContentType { get; set; }

        public DateTime CreatedDate { get; set; }

        public string Editor { get; set; }

        public string EditorAccount { get; set; }

        public string LatestVersion { get; set; }

        public DateTime Modified { get; set; }

        public string ModifiedBy { get; set; }

        public string Owner { get; set; }

        public int PublishingLevel { get; set; }

        public int Size { get; set; }

        public string Title { get; set; }

        public string UniqueID { get; set; }

        public string URL { get; set; }

        public string Version { get; set; }

        public int VirusStatus { get; set; }

        //public string Volume { get; set; }

        public string EncryptionType { get; set; }

        public string Extension { get; set; }



        internal static FeedIterator<T> GetItemQueryIterator<T>(QueryDefinition queryDefinition)

        {

            throw new NotImplementedException();

        }

    }



}
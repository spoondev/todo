﻿using System;

using Microsoft.Azure.Cosmos;
using Microsoft.Azure.Cosmos.Table;

namespace cosmosModels
{
    public class AmbassadorPathEntity : TableEntity
    {
        public AmbassadorPathEntity()
        {

        }
        //first few lines need a look at
        public AmbassadorPathEntity(int EmployeeId, string Path)
        {
            int PartitionKey = EmployeeId;
            string RowKey = Path;
        }
        public Int64 AmbassadorPathId { get; set; }
        public int EmployeeManagerId { get; set; }
        public string AdGroup { get; set; }
        public string OpCo { get; set; }
        public bool FraudFolder { get; set; }
        public bool SecurityFolder { get; set; }
        public bool HrFolder { get; set; }
        public DateTime ModifiedDate { get; set; }
        public DateTime CreatedDate { get; set; }
        public string ModifiedBy { get; set; }
        public string CreatedBy { get; set; }

        internal static FeedIterator<T> GetItemQueryIterator<T>(QueryDefinition queryDefinition)

        {

            throw new NotImplementedException();

        }

    }



}

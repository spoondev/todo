﻿using System;

using Microsoft.Azure.Cosmos;
using Microsoft.Azure.Cosmos.Table;

namespace cosmosModels
{
    public class FileInfoComplianceTypeEntity : TableEntity
    {
        public FileInfoComplianceTypeEntity()
        {
        }

        //public FileInfoComplianceTypeEntity()
        //{

        //}

        public Int64 FileInfoID { get; set; }
        public int ComplianceTypeId { get; set; }
        public DateTime ModifiedDate { get; set; }
        public DateTime CreatedDate { get; set; }
        public string ModifiedBy { get; set; }
        public string CreatedBy { get; set; }

        internal static FeedIterator<T> GetItemQueryIterator<T>(QueryDefinition queryDefinition)
        {
            throw new NotImplementedException();
        }
    }

}
﻿//using System.Threading;
//using System.Threading.Tasks;

//using cosmosModels;

//namespace DAI.Repository
//{
//    public interface IAmbassador
//    {
//        Task<AmbassadorPathEntity> GetAsync(int id, CancellationToken cancellationToken = default);
//        Task<ListResult<AmbassadorPathEntity>> GetAsync(int page = 1, int pageSize = 10, string sortColumn = "", SortOrder sortOrder = SortOrder.None, CancellationToken cancellationToken = default);
//        Task<PagedResult<AmbassadorPathEntity>> GetAsync(string searchCriteria, int page = 1, int pageSize = 10, string sortColumn = "", SortOrder sortOrder = SortOrder.None, CancellationToken cancellationToken = default);
//        Task<AmbassadorPathEntity> AddAsync(AmbassadorPathEntity entity, CancellationToken cancellationToken = default);
//        Task<bool> UpdateAsync(Ambassador entity, CancellationToken cancellationToken = default);
//        Task<bool> DeleteAsync(int id, CancellationToken cancellationToken = default);
        
//    }
//}




//using System.Linq;
//using System.Threading;
//using System.Threading.Tasks;
//using Microsoft.EntityFrameworkCore;

//using cosmosExporer.Common;
//using DAI.Model;
//using DAI.DataAccess;

//namespace DAI.Repository
//{
//    public class AmbassadorManager : IAmbassadorPath
//    {
//        private readonly DataContext _dataContext;

//        public AmbassadorManager(DataContext dataContext)
//        {
//            _dataContext = dataContext;
//        }


//        public async Task<Ambassador> GetAsync(int id, CancellationToken cancellationToken = default)
//        {
//            var ambassador = await _dataContext.Ambassadors
//                                    .Include(a => a.Employee)
//                                    .Include(a => a.EmployeeManager)
//                                    .SingleOrDefaultAsync(a => a.Id == id, cancellationToken);

//            return ambassador;
//        }

//        public async Task<PagedResult<Ambassador>> GetAsync(int page = 1, int pageSize = 10, string sortColumn = "", SortOrder sortOrder = SortOrder.None, CancellationToken cancellationToken = default)
//        {
//            return await _dataContext.Ambassadors.Include(a => a.Employee).Include(a => a.EmployeeManager).GetPaged(page, pageSize, sortColumn, sortOrder, cancellationToken);
//        }

//        public async Task<PagedResult<Ambassador>> GetAsync(string searchCriteria, int page = 1, int pageSize = 10, string sortColumn = "", SortOrder sortOrder = SortOrder.None, CancellationToken cancellationToken = default)
//        {
//            return await _dataContext.Ambassadors
//                                .Include(a => a.Employee)
//                                .Include(a => a.EmployeeManager)
//                                .Where(a => a.Path.Contains(searchCriteria) || a.OpCo.Contains(searchCriteria) || a.AdGroup.Contains(searchCriteria)
//                                                            || a.Employee.Email.Contains(searchCriteria) || a.Employee.LastName.Contains(searchCriteria) || a.Employee.FirstName.Contains(searchCriteria))
//                                .GetPaged(page, pageSize, sortColumn, sortOrder, cancellationToken);
//        }

﻿//using System.Collections.Generic;
//using System.Threading;
//using System.Threading.Tasks;

//using DAI.Common;
//using DAI.Model;

//namespace DAI.Repository
//{
//    public interface IFileInfo
//    {
//        Task<FileInfo> GetAsync(long id, CancellationToken cancellationToken = default);
//        Task<PagedResult<FileInfo>> GetAsync(int employeeId, int page = 1, int pageSize = 10, string sortColumn = "", SortOrder sortOrder = SortOrder.None, bool notSeenOnly = false, CancellationToken cancellationToken = default);
//        Task<PagedResult<FileInfo>> GetAsync(int employeeId, string searchCriteria, int page = 1, int pageSize = 10, string sortColumn = "", SortOrder sortOrder = SortOrder.None, bool notSeenOnly = false, CancellationToken cancellationToken = default);
//        Task<PagedResult<FileInfo>> GetByPathAsync(int employeeId, string path, int page = 1, int pageSize = 10, string sortColumn = "", SortOrder sortOrder = SortOrder.None, CancellationToken cancellationToken = default);
//        Task<PagedResult<FileInfo>> GetByExtensionAsync(int employeeId, string extension, int page = 1, int pageSize = 10, string sortColumn = "", SortOrder sortOrder = SortOrder.None, CancellationToken cancellationToken = default);
//        Task<PagedResult<FileInfo>> GetByProtectionTypeAsync(int employeeId, int protectionTypeId, int page = 1, int pageSize = 10, string sortColumn = "", SortOrder sortOrder = SortOrder.None, CancellationToken cancellationToken = default);
//        Task<PagedResult<FileInfo>> GetByComplianceTypesAsync(int employeeId, int[] complianceTypeIds, int page = 1, int pageSize = 10, string sortColumn = "", SortOrder sortOrder = SortOrder.None, CancellationToken cancellationToken = default);
//        Task<PagedResult<FileInfo>> GetAsync(string searchCriteria, int page = 1, int pageSize = 10, string sortColumn = "", SortOrder sortOrder = SortOrder.None, CancellationToken cancellationToken = default);
//        Task<PagedResult<FileInfo>> GetWithOwnershipQueryAsync(int page = 1, int pageSize = 10, string sortColumn = "", SortOrder sortOrder = SortOrder.None, CancellationToken cancellationToken = default);
//        Task<PagedResult<FileInfo>> GetWithOwnershipQueryAsync(string searchCriteria, int page = 1, int pageSize = 10, string sortColumn = "", SortOrder sortOrder = SortOrder.None, CancellationToken cancellationToken = default);
//        Task<PagedResult<FileInfo>> GetWithProtectionQueryAsync(int page = 1, int pageSize = 10, string sortColumn = "", SortOrder sortOrder = SortOrder.None, CancellationToken cancellationToken = default);
//        Task<PagedResult<FileInfo>> GetWithProtectionQueryAsync(string searchCriteria, int page = 1, int pageSize = 10, string sortColumn = "", SortOrder sortOrder = SortOrder.None, CancellationToken cancellationToken = default);
//        Task<FileInfo> AddAsync(FileInfo entity, CancellationToken cancellationToken = default);
//        Task<bool> UpdateAsync(FileInfo entity, CancellationToken cancellationToken = default);
//        Task UpdateOwnershipConfirmationAsync(IEnumerable<Confirmation> confirmations, CancellationToken cancellationToken = default);
//        Task UpdateProtectionConfirmationAsync(IEnumerable<Confirmation> confirmations, CancellationToken cancellationToken = default);
//        Task<bool> UpdateAssignedEmployeeAsync(long id, int employeeId, CancellationToken cancellationToken = default);
//        Task<bool> DeleteAsync(long Id, CancellationToken cancellationToken = default);
//        Task DeleteAsync(CancellationToken cancellationToken = default);
//        Task<IEnumerable<string>> GetFilePathsAsync(int employeeId, CancellationToken cancellationToken = default);
//        Task<IEnumerable<string>> GetFileExtensionsAsync(int employeeId, CancellationToken cancellationToken = default);
//        Task<IEnumerable<Employee>> GetFileAmbassadorsAsync(long id, CancellationToken cancellationToken = default);
//    }
//}
﻿using cosmosModels;

namespace cosmosExplorer
{
    using System.Linq;
    using System.Threading.Tasks;
    using System;
    using Microsoft.Azure.Cosmos.Table;

    class AmbassadorPathQueries
    {

        private readonly CloudConnection _cloudConnection;

        public AmbassadorPathQueries()
        {
            _cloudConnection = new CloudConnection();
        }
        public async Task RunAmbassadorPathQueries()
        {

            CloudTable table = _cloudConnection.GetClient().GetTableReference("ambassadorPathHistory");

            Console.WriteLine(table);

            try
            {
                await AmbassadorPathDataOperationsAsync(table);
                Console.WriteLine(table);
            }
            finally
            {
                // Delete the table
                Console.WriteLine("search complete");
            }
        }



        private static async Task AmbassadorPathDataOperationsAsync(CloudTable table)
        {

            Console.WriteLine("Please enter 1 or 2 to choose from the list of options what criteria you would like to search for:");
            Console.WriteLine("1. EmployeeID");
            Console.WriteLine("2. Path");
            Console.WriteLine("3. VolumeID");

            string userSelection;

            userSelection = Console.ReadLine();

            if (userSelection == "1")
            {
                string employeeIdForSelectAll;

                Console.WriteLine("enter EmployeeID (partitionkey) to return all results to console...");
                employeeIdForSelectAll = Console.ReadLine();

                TableQuery<AmbassadorPathEntity> ambassadorPathWhere = new TableQuery<AmbassadorPathEntity>().Where
                    (
                        TableQuery.GenerateFilterCondition("PartitionKey", QueryComparisons.Equal, employeeIdForSelectAll)
                    );

                var results = table.ExecuteQuery(ambassadorPathWhere);

                Console.WriteLine("Results follow the format 'EmployeeID', 'Path' , 'AmbassadorPathID'");

                if (results.Any())
                {
                    foreach (AmbassadorPathEntity ambassadorPath in results)
                    {
                        Console.WriteLine(ambassadorPath.PartitionKey + " | " + ambassadorPath.RowKey + " | " + ambassadorPath.AmbassadorPathId);
                    }
                }

            }
            if (userSelection == "2")
            {
                string pathStringForSelectAll;

                Console.WriteLine("enter the path in the format folder1/folder2");
                pathStringForSelectAll = Console.ReadLine();

                TableQuery<AmbassadorPathEntity> ambassadorPathWhere = new TableQuery<AmbassadorPathEntity>().Where
                    (
                        TableQuery.GenerateFilterCondition("Path", QueryComparisons.Equal, pathStringForSelectAll)
                    );

                var results = table.ExecuteQuery(ambassadorPathWhere);

                Console.WriteLine("Results follow the format 'EmployeeID', 'Path' , 'AmbassadorPathID'");



                if (results.Any())
                {
                    foreach (AmbassadorPathEntity ambassadorPath in results)
                    {
                        Console.WriteLine(ambassadorPath.PartitionKey + " | " + ambassadorPath.RowKey + " | " + ambassadorPath.AmbassadorPathId);
                    }
                }

            }
            if (userSelection == "3")
            {
                string volumeIdStringForSelectAll;

                Console.WriteLine("enter the path in the format folder1/folder2");
                volumeIdStringForSelectAll = Console.ReadLine();

                TableQuery<AmbassadorPathEntity> ambassadorPathWhere = new TableQuery<AmbassadorPathEntity>().Where
                    (
                        TableQuery.GenerateFilterCondition("Path", QueryComparisons.Equal, volumeIdStringForSelectAll)
                    );

                var results = table.ExecuteQuery(ambassadorPathWhere);

                Console.WriteLine("Results follow the format 'EmployeeID', 'Path' , 'AmbassadorPathID'");


                if (results.Any())
                {
                    foreach (AmbassadorPathEntity ambassadorPath in results)
                    {
                        Console.WriteLine(ambassadorPath.PartitionKey + " | " + ambassadorPath.RowKey + " | " + ambassadorPath.AmbassadorPathId);
                    }
                }

            }
        }
    }
}
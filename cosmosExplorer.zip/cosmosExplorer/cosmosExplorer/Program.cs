﻿using System;
using cosmosExplorer;
//using System.Threading.Tasks;

namespace CosmosTableSamples
{
    class Program
    {
        public static void Main(string[] args)
        {

            string userTableSelection = "";

            Console.WriteLine("Azure Cosmos Table Samples");

            Console.WriteLine("Choose from the following tables to query");
            Console.WriteLine("1. FileInfo");
            Console.WriteLine("2. Employee");
            Console.WriteLine("3. AddMetadata");
            Console.WriteLine("4. AmbassadorPath");

            userTableSelection = Console.ReadLine();

            if (userTableSelection == "1")
            {
                FileInfoQueries fileInfoQueries = new FileInfoQueries();
                fileInfoQueries.RunFileInfoQueries().Wait();
            }
            if (userTableSelection == "2")
            {
                EmployeeQueries employeeQueries = new EmployeeQueries();
                employeeQueries.RunEmployeeQueries().Wait();
            }
            if (userTableSelection == "3")
            {
                AddMetadataQueries addMetadataQueries = new AddMetadataQueries();
                addMetadataQueries.RunAddMetadataQueries().Wait();
            }
            if (userTableSelection == "4")
            {
                AmbassadorPathQueries ambassadorPathQueries = new AmbassadorPathQueries();
                ambassadorPathQueries.RunAmbassadorPathQueries().Wait();
            }
            //BasicSamples basicSamples = new BasicSamples();
            //basicSamples.RunSamples().Wait();

            //         AdvancedSamples advancedSamples = new AdvancedSamples();
            //          advancedSamples.RunSamples().Wait();

            Console.WriteLine();
            Console.WriteLine("Press any key to exit");
            Console.Read();
        }
    }
}
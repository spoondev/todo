﻿using Microsoft.Extensions.Configuration;
//using Microsoft.Extensions.Configuration.Memory;

namespace cosmosExplorer
{


    public class AppSettings
    {
        public string StorageConnectionString { get; set; }

        public static AppSettings LoadAppSettings()
        {
            IConfigurationRoot configRoot = new ConfigurationBuilder()
                .AddJsonFile("Settings1.json")
                .Build();

            AppSettings appSettings = configRoot.Get<AppSettings>();
            return appSettings;
        }
    }
}
﻿
using Microsoft.Azure.Cosmos.Table;

namespace cosmosExplorer
{
    public class CloudConnection
    {
        public CloudTableClient GetClient()
        {
            string storageConnectionString = AppSettings.LoadAppSettings().StorageConnectionString;

            CloudStorageAccount storageAccount = Common.CreateStorageAccountFromConnectionString(storageConnectionString);

            CloudTableClient tableClient = storageAccount.CreateCloudTableClient(new TableClientConfiguration());

            return (tableClient);

        }
    }
}


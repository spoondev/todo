﻿using System;
using cosmosModels;

namespace cosmosExplorer
{
    using System.Threading.Tasks;
    
    //using Microsoft.WindowsAzure.Storage.Table;
    using System;
    using System.Linq;
    using Microsoft.Azure.Cosmos.Table;
    //using Microsoft.WindowsAzure.Storage;

    //using System.ComponentModel;

    class AddMetadataQueries
    {
        private readonly CloudConnection _cloudConnection;

        public AddMetadataQueries()
        {
            _cloudConnection = new CloudConnection();
        }
        public async Task RunAddMetadataQueries()
        {

            CloudTable table = _cloudConnection.GetClient().GetTableReference("addMetadataHistory");

            Console.WriteLine(table);

            try
            {
                // Demonstrate basic CRUD functionality 
                //await QueryItemsAsync(table);
                await AddMetadataOperationsAsync(table);
                Console.WriteLine(table);
            }
            finally
            {
                // Delete the table
                Console.WriteLine("search complete");
            }
        }



        private static async Task AddMetadataOperationsAsync(CloudTable table)
        {
            string userSelection;
            int amIdForSelectAll;

            Console.WriteLine("Please enter a number to choose from the list of options for what criteria you would like to search for:");
            Console.WriteLine("1. amId");
            Console.WriteLine("2. fileInfoId");
            Console.WriteLine("3. author");

            userSelection = Console.ReadLine();


            if (userSelection == "1")
            {
                Console.WriteLine("enter amID to return all results for that number to console...");
                amIdForSelectAll = int.Parse(Console.ReadLine());

                TableQuery<AddMetadataEntity> EmployeeNumberWhere = new TableQuery<AddMetadataEntity>().Where
                    (
                        TableQuery.GenerateFilterConditionForInt("amID", QueryComparisons.Equal, amIdForSelectAll)
                    );

                var results = table.ExecuteQuery(EmployeeNumberWhere);

                Console.WriteLine("Results follow the format 'First name', 'Last name', 'email', 'Business area");

                if (results.Any())
                {
                    foreach (AddMetadataEntity addMetadata in results)
                    {
                        Console.WriteLine(
                                          "PartitionKey:     |" + addMetadata.PartitionKey + "\n"
                                        + "RowKey:           |" + addMetadata.RowKey + "\n"
                                        + "AccessedDate:     |" + addMetadata.AccessedDate + "\n"
                                        + "ApprovalStatus:   |" + addMetadata.ApprovalStatus + "\n"
                                        + "Author:           |" + addMetadata.Author + "\n"
                                        + "AuthorAccount:    |" + addMetadata.AuthorAccount + "\n"
                                        + "Category:         |" + addMetadata.Category + "\n"
                                        + "CheckedOutTo:     |" + addMetadata.CheckedOutTo + "\n"
                                        + "ContentType:      |" + addMetadata.ContentType + "\n"
                                        + "CreatedDate:      |" + addMetadata.CreatedDate + "\n"
                                        + "Editor:           |" + addMetadata.Editor + "\n"
                                        + "EditorAccount:    |" + addMetadata.EditorAccount + "\n"
                                        + "EncryptionType:   |" + addMetadata.EncryptionType + "\n"
                                        + "Extension:        |" + addMetadata.Extension + "\n"
                                        + "LatestVersion:    |" + addMetadata.LatestVersion + "\n"
                                        + "Modified:         |" + addMetadata.Modified + "\n"
                                        + "ModifiedBy:       |" + addMetadata.ModifiedBy + "\n"
                                        + "Owner:            |" + addMetadata.Owner + "\n"
                                        + "PublishingLevel:  |" + addMetadata.PublishingLevel + "\n"
                                        + "Size:             |" + addMetadata.Size + "\n"
                                        + "Title:            |" + addMetadata.Title + "\n"
                                        + "UniqueID:         |" + addMetadata.UniqueID + "\n"
                                        + "URL:              |" + addMetadata.URL + "\n"
                                        + "Version:          |" + addMetadata.Version + "\n"
                                        + "VirusStatus:      |" + addMetadata.VirusStatus + "\n"
                                        //+ "Volume:           |" + addMetadata.Volume + "\n"
                                        + "\n"
                                        + "-------------------"
                                        + "\n"
                                         );
                    }
                }

            }
            if (userSelection == "2")
            {
                //fileInfoID is the RowKey in the AddMetadata table
                string fileInfoIdForSelectAll;
                Console.WriteLine("enter fileInfoID to return a result to console...");
                fileInfoIdForSelectAll = Console.ReadLine();

                TableQuery<AddMetadataEntity> SearchViaFileInfo = new TableQuery<AddMetadataEntity>().Where
                    (
                        TableQuery.GenerateFilterCondition("RowKey", QueryComparisons.Equal, fileInfoIdForSelectAll)
                    );

                var results = table.ExecuteQuery(SearchViaFileInfo);


                if (results.Any())
                {
                    foreach (AddMetadataEntity addMetadata in results)
                    {
                        Console.WriteLine(
                                         addMetadata.RowKey
                                         //+ "RowKey:           |" + addMetadata.RowKey + "\n"
                                         //+ "AccessedDate:     |" + addMetadata.AccessedDate + "\n"
                                         //+ "ApprovalStatus:   |" + addMetadata.ApprovalStatus + "\n"
                                         //+ "Author:           |" + addMetadata.Author + "\n"
                                         //+ "AuthorAccount:    |" + addMetadata.AuthorAccount + "\n"
                                         //+ "Category:         |" + addMetadata.Category + "\n"
                                         //+ "CheckedOutTo:     |" + addMetadata.CheckedOutTo + "\n"
                                         //+ "ContentType:      |" + addMetadata.ContentType + "\n"
                                         //+ "CreatedDate:      |" + addMetadata.CreatedDate + "\n"
                                         //+ "Editor:           |" + addMetadata.Editor + "\n"
                                         //+ "EditorAccount:    |" + addMetadata.EditorAccount + "\n"
                                         //+ "EncryptionType:   |" + addMetadata.EncryptionType + "\n"
                                         //+ "Extension:        |" + addMetadata.Extension + "\n"
                                         //+ "LatestVersion:    |" + addMetadata.LatestVersion + "\n"
                                         //+ "Modified:         |" + addMetadata.Modified + "\n"
                                         //+ "ModifiedBy:       |" + addMetadata.ModifiedBy + "\n"
                                         //+ "Owner:            |" + addMetadata.Owner + "\n"
                                         //+ "PublishingLevel:  |" + addMetadata.PublishingLevel + "\n"
                                         //+ "Size:             |" + addMetadata.Size + "\n"
                                         //+ "Title:            |" + addMetadata.Title + "\n"
                                         //+ "UniqueID:         |" + addMetadata.UniqueID + "\n"
                                         //+ "URL:              |" + addMetadata.URL + "\n"
                                         //+ "Version:          |" + addMetadata.Version + "\n"
                                         //+ "VirusStatus:      |" + addMetadata.VirusStatus + "\n"
                                         ////+ "Volume:           |" + addMetadata.Volume + "\n"
                                         //+ "\n"
                                         //+ "-------------------"
                                         //+ "\n"
                                         );
                    }
                }

            }
            if (userSelection == "3")
            {
                string authorStringForSelectAll;

                Console.WriteLine("enter the name of an author to return all results to console for the selected individual");
                authorStringForSelectAll = Console.ReadLine();

                TableQuery<AddMetadataEntity> SearchByAuthor = new TableQuery<AddMetadataEntity>().Where(

                        TableQuery.GenerateFilterCondition("Author", QueryComparisons.Equal, authorStringForSelectAll)
                    );

                var results = table.ExecuteQuery(SearchByAuthor);


                if (results.Any())
                {
                    foreach (AddMetadataEntity addMetadata in results)
                    {
                        Console.WriteLine(
                                          "PartitionKey:     |" + addMetadata.PartitionKey + "\n"
                                        + "RowKey:           |" + addMetadata.RowKey + "\n"
                                        + "AccessedDate:     |" + addMetadata.AccessedDate + "\n"
                                        + "ApprovalStatus:   |" + addMetadata.ApprovalStatus + "\n"
                                        + "Author:           |" + addMetadata.Author + "\n"
                                        + "AuthorAccount:    |" + addMetadata.AuthorAccount + "\n"
                                        + "Category:         |" + addMetadata.Category + "\n"
                                        + "CheckedOutTo:     |" + addMetadata.CheckedOutTo + "\n"
                                        + "ContentType:      |" + addMetadata.ContentType + "\n"
                                        + "CreatedDate:      |" + addMetadata.CreatedDate + "\n"
                                        + "Editor:           |" + addMetadata.Editor + "\n"
                                        + "EditorAccount:    |" + addMetadata.EditorAccount + "\n"
                                        + "EncryptionType:   |" + addMetadata.EncryptionType + "\n"
                                        + "Extension:        |" + addMetadata.Extension + "\n"
                                        + "LatestVersion:    |" + addMetadata.LatestVersion + "\n"
                                        + "Modified:         |" + addMetadata.Modified + "\n"
                                        + "ModifiedBy:       |" + addMetadata.ModifiedBy + "\n"
                                        + "Owner:            |" + addMetadata.Owner + "\n"
                                        + "PublishingLevel:  |" + addMetadata.PublishingLevel + "\n"
                                        + "Size:             |" + addMetadata.Size + "\n"
                                        + "Title:            |" + addMetadata.Title + "\n"
                                        + "UniqueID:         |" + addMetadata.UniqueID + "\n"
                                        + "URL:              |" + addMetadata.URL + "\n"
                                        + "Version:          |" + addMetadata.Version + "\n"
                                        + "VirusStatus:      |" + addMetadata.VirusStatus + "\n"
                                        //+ "Volume:           |" + addMetadata.Volume + "\n"
                                        + "\n"
                                        + "-------------------"
                                        + "\n"
                                         );
                    }
                }

            }
            //if (userSelection == "4")
            //{
            //    Console.WriteLine("enter email to return all results to console for the selected email");
            //    authorStringForSelectAll = Console.ReadLine();

            //    TableQuery<EmployeeEntity> fileInfoWhere = new TableQuery<EmployeeEntity>().Where(

            //            TableQuery.GenerateFilterCondition("PartitionKey", QueryComparisons.Equal, domaineQualifiedUsernameStringForSelectAll)
            //        );

            //    var results = table.ExecuteQuery(fileInfoWhere);

            //    Console.WriteLine("Results follow the format 'First name', 'Last name', 'email', 'Business area");

            //    if (results.Any())
            //    {
            //        foreach (EmployeeEntity employee in results)
            //        {
            //            Console.WriteLine(employee.EmployeeFirst + " | " + employee.EmployeeLast + " | " + employee.Email + " | " + employee.BusinessArea);
            //        }
            //    }
            //}


            // <summary>
            // Run a query(using Azure Cosmos DB SQL syntax) against the container
            // </summary>
            //    private static async Task QueryItemsAsync(CloudTable table)
            //{
            //    var sqlQueryText = "SELECT * FROM fileInfoHistory WHERE fileInfoHistory.PartitionKey = 6";

            //    Console.WriteLine("Running query: {0}\n", sqlQueryText);

            //    //may not have defined the querydefinition properly
            //    QueryDefinition queryDefinition = new QueryDefinition(sqlQueryText);
            //    FeedIterator<FileInfoEntity> queryResultSetIterator = FileInfoEntity.GetItemQueryIterator<FileInfoEntity>(queryDefinition);

            //    List<FileInfoEntity> fileInfos = new List<FileInfoEntity>();

            //    while (queryResultSetIterator.HasMoreResults)
            //    {
            //        FeedResponse<FileInfoEntity> currentResultSet = await queryResultSetIterator.ReadNextAsync();
            //        foreach (FileInfoEntity fileInfo in currentResultSet)
            //        {
            //            fileInfos.Add(fileInfo);
            //            Console.WriteLine("\tRead {0}\n", fileInfo);
            //        }
            //    }
            //}

            //    private static void FeedIterator()
            //    {
            //        throw new NotImplementedException();
            //    }


            //Console.WriteLine(results);

            //Console.WriteLine(results);

            //Console.WriteLine("Results follow the format 'fileName', 'path', 'volumeID'");

            //if (results.Any())
            //{
            //    foreach (FileInfoEntity fileInfo in results)
            //    {
            //        //Console.WriteLine("FileName" + "  |  " + "Path" + "  |  " + "VolumeID");
            //        Console.WriteLine(fileInfo.FileName + " | " + fileInfo.Path + " | " + fileInfo.VolumeID);
            //        //Console.WriteLine(fileInfo.Path);
            //        //Console.WriteLine(fileInfo.PartitionKey);
            //    }
            //}

            //string pkFilter = TableQuery<FileInfoEntity>.GenerateFilterCondition("PartitionKey", QueryComparisons.Equal, 6.ToString());

            //Console.WriteLine(pkFilter);

            //string filter = Console.ReadLine();
            //IList<string> column;
            //var tableQuery = new TableQuery<DynamicTableEntity>().Select(column).Where(File);
            //var tableResult = table.ExecuteQuery(tableQuery);

            //Console.WriteLine("Azure Cosmos DB Table - Basic Samples\n");
            //Console.WriteLine();
            //Console.WriteLine("enter partitionkey try 6 if you haven't got one in mind");
            //partitionstring = int.Parse(Console.ReadLine());

            //Console.WriteLine("enter rowkey try 509 if you haven't got one in mind");
            //rowkeystring = int.Parse(Console.ReadLine());



            //// Demonstrate how to Read the updated entity using a point query 
            //Console.WriteLine("Reading the updated Entity.");
            //FileInfoEntity clive = await SamplesUtils.RetrieveEntityUsingPointQueryAsync(table, partitionstring, rowkeystring);
            //Console.WriteLine(clive.FileName);
            //Console.WriteLine(clive.FileExtension);
            //Console.WriteLine(clive.Path);


            //Console.ReadLine();

            //Console.WriteLine("hopefully something will happen now");
            ////Constructing the fileInfoQuery to get the employeeID and the fileInfoID 
            //TableQuery<DynamicTableEntity> fileInfoQuery = new TableQuery<DynamicTableEntity>().Select(new string[] { "fileName", "path" });

            ////Creating an entity resolver to work with the entity after it is retrieved
            //EntityResolver<FileInfoEntity> resolver = (pk, rk, ts, props, etag) => new FileInfoEntity
            //{
            //    FileName = props["fileName"].StringValue,
            //    Path = props["path"].StringValue
            //};

            //foreach (FileInfoEntity projectedFileInfo in table.ExecuteQuery(fileInfoQuery, resolver, null, null))
            //{
            //    Console.WriteLine("{0}\t{1}", projectedFileInfo.FileName, projectedFileInfo.Path);
            //}

            //                int PartitionKey = employeeID;
            //    Int64 RowKey = fileInfoID;
            //}

            //public string FileName { get; set; }
            //public string FileExtension { get; set; }
            //public string Path { get; set; }
            //public string ContainerPath { get; set; }

            //// Demonstrate how to Delete an entity
            //Console.WriteLine("Delete the entity. ");
            //await SamplesUtils.DeleteEntityAsync(table, customer);
            //Console.WriteLine();
            //}
        }
    }

}
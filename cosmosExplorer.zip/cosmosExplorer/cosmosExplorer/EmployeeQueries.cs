﻿using System;

namespace cosmosExplorer
{

    using System.Threading.Tasks;
    using System;
    using System.Linq;
    using cosmosModels;
    using Microsoft.Azure.Cosmos.Table;

    class EmployeeQueries
    {

        private readonly CloudConnection _cloudConnection;

        public EmployeeQueries()
        {
            _cloudConnection = new CloudConnection();
        }
        public async Task RunEmployeeQueries()
        {

            CloudTable table = _cloudConnection.GetClient().GetTableReference("employeeHistory");

            Console.WriteLine(table);

            try
            {
                await EmployeeDataOperationsAsync(table);
                Console.WriteLine(table);
            }
            finally
            {
                Console.WriteLine("search complete");
            }
        }



        private static async Task EmployeeDataOperationsAsync(CloudTable table)
        {


            //int partitionstring = 0;
            //Int64 rowkeystring = 0;
            int employeeIdForselectall = 0;
            int employeeNumberForSelectAll = 0;
            string userSelection = "";
            string domaineQualifiedUsernameStringForSelectAll = "";

            Console.WriteLine("Please enter 1 or 2 to choose from the list of options what criteria you would like to search for:");
            Console.WriteLine("1. EmployeeID");
            Console.WriteLine("2. EmployeeNumber (AXA Internal) NOTE: Contractors do not have employee numbers");
            Console.WriteLine("3. DomainQualifiedUserName (PartitionKey)");
            Console.WriteLine("4. Email");

            userSelection = Console.ReadLine();

            if (userSelection == "1")
            {
                Console.WriteLine("Enter employeeID to search for (DAI employeeID does not correspond to employee number");
                employeeIdForselectall = int.Parse(Console.ReadLine());

                TableQuery<EmployeeEntity> EmployeeIDWhere = new TableQuery<EmployeeEntity>().Where
                    (

                        TableQuery.GenerateFilterConditionForInt("EmployeeID", QueryComparisons.Equal, employeeIdForselectall)

                    );

                var results = table.ExecuteQuery(EmployeeIDWhere);

                Console.WriteLine("Results follow the format 'First name', 'Last name', 'email', 'Business area");

                if (results.Any())
                {
                    foreach (EmployeeEntity employee in results)
                    {
                        Console.WriteLine(employee.EmployeeFirst + " | " + employee.EmployeeLast + " | " + employee.Email + " | " + employee.BusinessArea);
                    }
                }

            }
            if (userSelection == "2")
            {
                Console.WriteLine("enter employee number to return all results for that number to console...");
                employeeNumberForSelectAll = int.Parse(Console.ReadLine());

                TableQuery<EmployeeEntity> EmployeeNumberWhere = new TableQuery<EmployeeEntity>().Where
                    (
                        TableQuery.GenerateFilterConditionForInt("EmployeeNumber", QueryComparisons.Equal, employeeNumberForSelectAll)
                    );

                var results = table.ExecuteQuery(EmployeeNumberWhere);

                Console.WriteLine("Results follow the format 'First name', 'Last name', 'email', 'Business area");

                if (results.Any())
                {
                    foreach (EmployeeEntity employee in results)
                    {
                        Console.WriteLine(employee.EmployeeFirst + " | " + employee.EmployeeLast + " | " + employee.Email + " | " + employee.BusinessArea);
                    }
                }

            }
            if (userSelection == "3")
            {
                Console.WriteLine("enter domain qualified username to return all results to console for the selected DQU");
                domaineQualifiedUsernameStringForSelectAll = Console.ReadLine();

                TableQuery<EmployeeEntity> fileInfoWhere = new TableQuery<EmployeeEntity>().Where(

                        TableQuery.GenerateFilterCondition("PartitionKey", QueryComparisons.Equal, domaineQualifiedUsernameStringForSelectAll)
                    );

                var results = table.ExecuteQuery(fileInfoWhere);

                Console.WriteLine("Results follow the format 'First name', 'Last name', 'email', 'Business area");

                if (results.Any())
                {
                    foreach (EmployeeEntity employee in results)
                    {
                        Console.WriteLine(employee.EmployeeFirst + " | " + employee.EmployeeLast + " | " + employee.Email + " | " + employee.BusinessArea);
                    }
                }
            }
            if (userSelection == "4")
            {
                string emailStringForSelectAll;

                Console.WriteLine("enter email to return all results to console for the selected email");
                emailStringForSelectAll = Console.ReadLine();

                TableQuery<EmployeeEntity> EmployeeWhere = new TableQuery<EmployeeEntity>().Where(

                        TableQuery.GenerateFilterCondition("Email", QueryComparisons.Equal, emailStringForSelectAll)
                    );

                var results = table.ExecuteQuery(EmployeeWhere);

                Console.WriteLine("Results follow the format 'First name', 'Last name', 'email', 'Business area");

                if (results.Any())
                {
                    foreach (EmployeeEntity employee in results)
                    {
                        Console.WriteLine(employee.EmployeeFirst + " | " + employee.EmployeeLast + " | " + employee.Email + " | " + employee.BusinessArea);
                    }
                }
            }


            // <summary>
            // Run a query(using Azure Cosmos DB SQL syntax) against the container
            // </summary>
            //    private static async Task QueryItemsAsync(CloudTable table)
            //{
            //    var sqlQueryText = "SELECT * FROM fileInfoHistory WHERE fileInfoHistory.PartitionKey = 6";

            //    Console.WriteLine("Running query: {0}\n", sqlQueryText);

            //    //may not have defined the querydefinition properly
            //    QueryDefinition queryDefinition = new QueryDefinition(sqlQueryText);
            //    FeedIterator<FileInfoEntity> queryResultSetIterator = FileInfoEntity.GetItemQueryIterator<FileInfoEntity>(queryDefinition);

            //    List<FileInfoEntity> fileInfos = new List<FileInfoEntity>();

            //    while (queryResultSetIterator.HasMoreResults)
            //    {
            //        FeedResponse<FileInfoEntity> currentResultSet = await queryResultSetIterator.ReadNextAsync();
            //        foreach (FileInfoEntity fileInfo in currentResultSet)
            //        {
            //            fileInfos.Add(fileInfo);
            //            Console.WriteLine("\tRead {0}\n", fileInfo);
            //        }
            //    }
            //}

            //    private static void FeedIterator()
            //    {
            //        throw new NotImplementedException();
            //    }


            //Console.WriteLine(results);

            //Console.WriteLine(results);

            //Console.WriteLine("Results follow the format 'fileName', 'path', 'volumeID'");

            //if (results.Any())
            //{
            //    foreach (FileInfoEntity fileInfo in results)
            //    {
            //        //Console.WriteLine("FileName" + "  |  " + "Path" + "  |  " + "VolumeID");
            //        Console.WriteLine(fileInfo.FileName + " | " + fileInfo.Path + " | " + fileInfo.VolumeID);
            //        //Console.WriteLine(fileInfo.Path);
            //        //Console.WriteLine(fileInfo.PartitionKey);
            //    }
            //}

            //string pkFilter = TableQuery<FileInfoEntity>.GenerateFilterCondition("PartitionKey", QueryComparisons.Equal, 6.ToString());

            //Console.WriteLine(pkFilter);

            //string filter = Console.ReadLine();
            //IList<string> column;
            //var tableQuery = new TableQuery<DynamicTableEntity>().Select(column).Where(File);
            //var tableResult = table.ExecuteQuery(tableQuery);

            //Console.WriteLine("Azure Cosmos DB Table - Basic Samples\n");
            //Console.WriteLine();
            //Console.WriteLine("enter partitionkey try 6 if you haven't got one in mind");
            //partitionstring = int.Parse(Console.ReadLine());

            //Console.WriteLine("enter rowkey try 509 if you haven't got one in mind");
            //rowkeystring = int.Parse(Console.ReadLine());



            //// Demonstrate how to Read the updated entity using a point query 
            //Console.WriteLine("Reading the updated Entity.");
            //FileInfoEntity clive = await SamplesUtils.RetrieveEntityUsingPointQueryAsync(table, partitionstring, rowkeystring);
            //Console.WriteLine(clive.FileName);
            //Console.WriteLine(clive.FileExtension);
            //Console.WriteLine(clive.Path);


            //Console.ReadLine();

            //Console.WriteLine("hopefully something will happen now");
            ////Constructing the fileInfoQuery to get the employeeID and the fileInfoID 
            //TableQuery<DynamicTableEntity> fileInfoQuery = new TableQuery<DynamicTableEntity>().Select(new string[] { "fileName", "path" });

            ////Creating an entity resolver to work with the entity after it is retrieved
            //EntityResolver<FileInfoEntity> resolver = (pk, rk, ts, props, etag) => new FileInfoEntity
            //{
            //    FileName = props["fileName"].StringValue,
            //    Path = props["path"].StringValue
            //};

            //foreach (FileInfoEntity projectedFileInfo in table.ExecuteQuery(fileInfoQuery, resolver, null, null))
            //{
            //    Console.WriteLine("{0}\t{1}", projectedFileInfo.FileName, projectedFileInfo.Path);
            //}

            //                int PartitionKey = employeeID;
            //    Int64 RowKey = fileInfoID;
            //}

            //public string FileName { get; set; }
            //public string FileExtension { get; set; }
            //public string Path { get; set; }
            //public string ContainerPath { get; set; }

            //// Demonstrate how to Delete an entity
            //Console.WriteLine("Delete the entity. ");
            //await SamplesUtils.DeleteEntityAsync(table, customer);
            //Console.WriteLine();
            //}
        }
    }

}
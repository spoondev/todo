﻿using System;
using cosmosModels;
using Microsoft.Azure.Cosmos.Table;
using System.Linq;
using System.Threading.Tasks;

namespace cosmosExplorer
{
    class FileInfoComplianceTypeQueries
    {

        private readonly CloudConnection _cloudConnection;

        public FileInfoComplianceTypeQueries()
        {
            _cloudConnection = new CloudConnection();
        }
        public async Task RunFileInfoComplianceTypeQueries()
        {

            CloudTable table = _cloudConnection.GetClient().GetTableReference("fileInfoComplianceTypeHistory");

            Console.WriteLine(table);


            try
            {
                // Demonstrate basic CRUD functionality 
                //await QueryItemsAsync(table);
                await FileInfoComplianceTypeDataOperationsAsync(table);
                Console.WriteLine(table);
            }
            finally
            {
                // Delete the table
                Console.WriteLine("search complete");
            }
        }


        private static async Task FileInfoComplianceTypeDataOperationsAsync(CloudTable table)
        {


            //int partitionstring = 0;
            //Int64 rowkeystring = 0;
            int partitionstringforselectall;
            int rowstringforselectall;
            string userSelection;
            Int32 volumestringforselectall;

            Console.WriteLine("Please enter 1 or 2 to choose from the list of options what criteria you would like to search for:");
            Console.WriteLine("1. ComplianceTypeID");
            Console.WriteLine("2. FileInfoID");
            Console.WriteLine("3. ComplianceTypeID and Date Range");
            Console.WriteLine("4. EmployeeID & Date Range");
            Console.WriteLine("5. AssignedEmployeeID");

            userSelection = Console.ReadLine();

            if (userSelection == "1")
            {
                Console.WriteLine("enter partitionkey to return all results to console...");
                partitionstringforselectall = int.Parse(Console.ReadLine());

                TableQuery<FileInfoEntity> fileInfoWhere = new TableQuery<FileInfoEntity>().Where(

                        TableQuery.GenerateFilterCondition("PartitionKey", QueryComparisons.Equal, partitionstringforselectall.ToString())
                    );

                var results = table.ExecuteQuery(fileInfoWhere);

                Console.WriteLine("Results follow the format 'fileName', 'path', 'volumeID'");

                if (results.Any())
                {
                    foreach (FileInfoEntity fileInfo in results)
                    {
                        Console.WriteLine(fileInfo.FileName + " | " + fileInfo.Path + " | " + fileInfo.VolumeID);
                    }
                }

            }
            if (userSelection == "2")
            {
                Console.WriteLine("enter fileInfoID to return a result to console...");
                rowstringforselectall = int.Parse(Console.ReadLine());

                TableQuery<FileInfoEntity> fileInfoWhere = new TableQuery<FileInfoEntity>().Where(
                        //TableQuery.CombineFilters(
                        TableQuery.GenerateFilterCondition("RowKey", QueryComparisons.Equal, rowstringforselectall.ToString())
                    //TableOperators.And,
                    //TableQuery.GenerateFilterConditionForInt("PartitionKey", QueryComparisons.GreaterThan,  0)

                    );

                var results = table.ExecuteQuery(fileInfoWhere);

                Console.WriteLine("Results follow the format 'fileName', 'path', 'volumeID'");

                if (results.Any())
                {
                    foreach (FileInfoEntity fileInfo in results)
                    {
                        Console.WriteLine(fileInfo.FileName + " | " + fileInfo.Path + " | " + fileInfo.VolumeID);
                    }
                }

            }
            if (userSelection == "3")
            {
                Console.WriteLine("enter VolumeID to return all results to console...");
                volumestringforselectall = Int32.Parse(Console.ReadLine());

                TableQuery<FileInfoEntity> fileInfoWhere = new TableQuery<FileInfoEntity>().Where(
                        //TableQuery.CombineFilters(
                        TableQuery.GenerateFilterConditionForInt("VolumeID", QueryComparisons.Equal, volumestringforselectall)
                    //TableOperators.And,
                    //TableQuery.GenerateFilterConditionForInt("PartitionKey", QueryComparisons.GreaterThan,  0)

                    );

                var results = table.ExecuteQuery(fileInfoWhere);

                Console.WriteLine("Results follow the format 'fileName', 'path', 'volumeID'");

                if (results.Any())
                {
                    foreach (FileInfoEntity fileInfo in results)
                    {
                        Console.WriteLine(fileInfo.FileName + " | " + fileInfo.Path + " | " + fileInfo.VolumeID);
                    }
                }

            }
            if (userSelection == "4")
            {

                Console.WriteLine("Enter EmployeeID");
                string employeeIDforselectall = Console.ReadLine();
                Console.WriteLine("Enter start date in format: dd/mm/yyyy hh:mm:ss");
                DateTime startDate = DateTime.Parse(Console.ReadLine());
                Console.WriteLine("Enter end date in format: dd/mm/yyyy hh:mm:ss");
                DateTime endDate = DateTime.Parse(Console.ReadLine());


                string date1 = TableQuery.GenerateFilterConditionForDate("ModifiedDate", QueryComparisons.GreaterThanOrEqual, startDate);

                string date2 = TableQuery.GenerateFilterConditionForDate("ModifiedDate", QueryComparisons.LessThanOrEqual, endDate);

                string employee = TableQuery.GenerateFilterCondition("PartitionKey", QueryComparisons.Equal, employeeIDforselectall);

                //string finalfilter = TableQuery.CombineFilters(TableQuery.CombineFilters(employee, TableOperators.And, date1),TableOperators.And,date2);

                string finalfilter = TableQuery.CombineFilters(employee, TableOperators.And, date1);

                TableQuery<FileInfoEntity> fileInfoWhere = new TableQuery<FileInfoEntity>().Where(

                        TableQuery.CombineFilters(finalfilter, TableOperators.And, date2)

                    );

                var results = table.ExecuteQuery(fileInfoWhere);

                Console.WriteLine("Results follow the format 'fileName', 'path', 'volumeID'");

                if (results.Any())
                {
                    foreach (FileInfoEntity fileInfo in results)
                    {
                        Console.WriteLine(fileInfo.FileName + " | " + fileInfo.Path + " | " + fileInfo.VolumeID);
                    }
                }


                //Console.WriteLine(results);

                //Console.WriteLine(results);

                //Console.WriteLine("Results follow the format 'fileName', 'path', 'volumeID'");

                //if (results.Any())
                //{
                //    foreach (FileInfoEntity fileInfo in results)
                //    {
                //        //Console.WriteLine("FileName" + "  |  " + "Path" + "  |  " + "VolumeID");
                //        Console.WriteLine(fileInfo.FileName + " | " + fileInfo.Path + " | " + fileInfo.VolumeID);
                //        //Console.WriteLine(fileInfo.Path);
                //        //Console.WriteLine(fileInfo.PartitionKey);
                //    }
                //}

                //string pkFilter = TableQuery<FileInfoEntity>.GenerateFilterCondition("PartitionKey", QueryComparisons.Equal, 6.ToString());

                //Console.WriteLine(pkFilter);

                //string filter = Console.ReadLine();
                //IList<string> column;
                //var tableQuery = new TableQuery<DynamicTableEntity>().Select(column).Where(File);
                //var tableResult = table.ExecuteQuery(tableQuery);

                //Console.WriteLine("Azure Cosmos DB Table - Basic Samples\n");
                //Console.WriteLine();
                //Console.WriteLine("enter partitionkey try 6 if you haven't got one in mind");
                //partitionstring = int.Parse(Console.ReadLine());

                //Console.WriteLine("enter rowkey try 509 if you haven't got one in mind");
                //rowkeystring = int.Parse(Console.ReadLine());



                //// Demonstrate how to Read the updated entity using a point query 
                //Console.WriteLine("Reading the updated Entity.");
                //FileInfoEntity clive = await SamplesUtils.RetrieveEntityUsingPointQueryAsync(table, partitionstring, rowkeystring);
                //Console.WriteLine(clive.FileName);
                //Console.WriteLine(clive.FileExtension);
                //Console.WriteLine(clive.Path);


                //Console.ReadLine();

                //Console.WriteLine("hopefully something will happen now");
                ////Constructing the fileInfoQuery to get the employeeID and the fileInfoID 
                //TableQuery<DynamicTableEntity> fileInfoQuery = new TableQuery<DynamicTableEntity>().Select(new string[] { "fileName", "path" });

                ////Creating an entity resolver to work with the entity after it is retrieved
                //EntityResolver<FileInfoEntity> resolver = (pk, rk, ts, props, etag) => new FileInfoEntity
                //{
                //    FileName = props["fileName"].StringValue,
                //    Path = props["path"].StringValue
                //};

                //foreach (FileInfoEntity projectedFileInfo in table.ExecuteQuery(fileInfoQuery, resolver, null, null))
                //{
                //    Console.WriteLine("{0}\t{1}", projectedFileInfo.FileName, projectedFileInfo.Path);
                //}

                //                int PartitionKey = employeeID;
                //    Int64 RowKey = fileInfoID;
                //}

                //public string FileName { get; set; }
                //public string FileExtension { get; set; }
                //public string Path { get; set; }
                //public string ContainerPath { get; set; }

                //// Demonstrate how to Delete an entity
                //Console.WriteLine("Delete the entity. ");
                //await SamplesUtils.DeleteEntityAsync(table, customer);
                //Console.WriteLine();
                //}
            }
        }

    }
}
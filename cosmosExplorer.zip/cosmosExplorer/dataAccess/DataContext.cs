﻿//using System;
//using System.Threading;
//using System.Threading.Tasks;
//using System.Linq;
//using Microsoft.EntityFrameworkCore;
//using Microsoft.EntityFrameworkCore.Metadata;
//using Microsoft.AspNetCore.Http;

//using cosmosModels;

//namespace DAI.DataAccess
//{
//    public class DataContext : DbContext
//    {
//        private readonly string _currentUser = "";

//        public DataContext(DbContextOptions<DataContext> options, IHttpContextAccessor httpContextAccessor = null) : base(options)
//        {
//            if (httpContextAccessor != null)
//                _currentUser = httpContextAccessor.HttpContext.User.Identity.Name;

//            if (String.IsNullOrEmpty(_currentUser) && httpContextAccessor != null && httpContextAccessor.HttpContext.Request.Headers.Keys.Any(key => key == "User"))
//                _currentUser = httpContextAccessor.HttpContext.Request.Headers["User"];

//            if (String.IsNullOrEmpty(_currentUser))
//                _currentUser = "Not supplied";
//        }

//        public override Task<int> SaveChangesAsync(CancellationToken cancellationToken = default(CancellationToken))
//        {
//            return SaveChangesAsync(true, cancellationToken);
//        }

//        public override Task<int> SaveChangesAsync(bool acceptAllChangesOnSuccess, CancellationToken cancellationToken = default(CancellationToken))
//        {
//            const string CreatedDate = "CreatedDate";
//            const string CreatedBy = "CreatedBy";
//            const string ModifiedDate = "ModifiedDate";
//            const string ModifiedBy = "ModifiedBy";
//            var dateTimeNow = DateTime.UtcNow;
//            IProperty property;

//            var AddedEntities = ChangeTracker.Entries().Where(E => E.State == EntityState.Added).ToList();
//            AddedEntities.ForEach(E =>
//            {
//                property = E.Metadata.FindProperty(CreatedDate);
//                if (property != null)
//                    E.Property(CreatedDate).CurrentValue = dateTimeNow;

//                property = E.Metadata.FindProperty(ModifiedDate);
//                if (property != null)
//                    E.Property(ModifiedDate).CurrentValue = dateTimeNow;

//                property = E.Metadata.FindProperty(CreatedBy);
//                if (property != null)
//                    E.Property(CreatedBy).CurrentValue = _currentUser;

//                property = E.Metadata.FindProperty(ModifiedBy);
//                if (property != null)
//                    E.Property(ModifiedBy).CurrentValue = _currentUser;
//            });

//            var EditedEntities = ChangeTracker.Entries().Where(E => E.State == EntityState.Modified).ToList();
//            EditedEntities.ForEach(E =>
//            {
//                property = E.Metadata.FindProperty(ModifiedDate);
//                if (property != null)
//                    E.Property(ModifiedDate).CurrentValue = dateTimeNow;

//                property = E.Metadata.FindProperty(ModifiedBy);
//                if (property != null)
//                    E.Property(ModifiedBy).CurrentValue = _currentUser;

//            });

//            return base.SaveChangesAsync(acceptAllChangesOnSuccess, cancellationToken);
//        }

//        protected override void OnModelCreating(ModelBuilder modelBuilder)
//        {
//            modelBuilder.Entity<FileInfoComplianceType>()
//                    .HasKey(fp => new { fp.ComplianceTypeId, fp.FileInfoId });
//            modelBuilder.Entity<FileInfoComplianceType>()
//                .HasOne(fp => fp.ComplianceType)
//                .WithMany(p => p.FileInfoComplianceTypes)
//                .HasForeignKey(fp => fp.ComplianceTypeId);
//            //modelBuilder.Entity<FileInfoComplianceType>()
//            //    .HasOne(fp => fp.FileInfo)
//            //    .WithMany(f => f.FileInfoComplianceTypes)
//            //    .HasForeignKey(fp => fp.FileInfoId);
//        }


//        //Tables
//        public DbSet<Employee> Employees { get; set; }
//        public DbSet<FileInfo> FileInfos { get; set; }
//        public DbSet<FileNote> FileNotes { get; set; }
//        public DbSet<UserAction> UserActions { get; set; }
//        public DbSet<FileInfoComplianceType> FileInfoComplianceTypes { get; set; }
//        public DbSet<ComplianceType> ComplianceTypes { get; set; }
//        public DbSet<ProtectionType> ProtectionTypes { get; set; }
//        public DbSet<Ambassador> Ambassadors { get; set; }
//        public DbSet<Volume> Volumes { get; set; }
//        public DbSet<ExceptionType> ExceptionTypes { get; set; }
//        public DbSet<Model.Exception> Exceptions { get; set; }
//        public DbSet<ObjectType> ObjectTypes { get; set; }

//        //Stored Procedure Results
//        public DbSet<ClassificationCount> ClassificationCounts { get; set; }
//        public DbSet<EmployeeFilesSeenCount> EmployeeFilesSeenCounts { get; set; }
//    }
//}

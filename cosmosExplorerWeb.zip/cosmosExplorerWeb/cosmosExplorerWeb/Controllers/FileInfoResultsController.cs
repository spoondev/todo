﻿using cosmosExplorerWeb.Models;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Models;
using System.Collections.Generic;
using DataAccessLayer;

namespace cosmosExplorerWeb.Controllers
{
    public class FileInfoResultsController : Controller
    {
        // GET: FileInfoResults
        public ActionResult Index()
        {
            return View();
        }

        //    // Lets start populating the view model.
        //    FileInfoResultsModel model = new FileInfoResultsModel();

        //    // Project the results to your model.
        //    IList<FileInfoModel> fileInfoModels = null;
        //    if (resultsFromTable != null)
        //    {
        //        model.FileInfoModels = (from FileInfoModel in resultsFromTable
        //                           select new FileInfoModel()
        //                           {
        //                               PartitionKey = FileInfoModel.PartitionKey,
        //                               FileName = FileInfoModel.FileName,
        //                               Path = FileInfoModel.Path,
        //                               VolumeID = FileInfoModel.VolumeID,
        //                               ProtectionTypeID = FileInfoModel.ProtectionTypeID

        //                           }).ToList();
        //    }

        //    // Anything else...

        //    return View(model);
        //}

        // GET: FileInfoResults/Details/5
        public ActionResult Details(int id)
        {
            return View();
        }

        // GET: FileInfoResults/Create
        public ActionResult Create()
        {
            return View();
        }

        // POST: FileInfoResults/Create
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Create(IFormCollection collection)
        {
            try
            {
                // TODO: Add insert logic here

                return RedirectToAction(nameof(Index));
            }
            catch
            {
                return View();
            }
        }

        // GET: FileInfoResults/Edit/5
        public ActionResult Edit(int id)
        {
            return View();
        }

        // POST: FileInfoResults/Edit/5
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Edit(int id, IFormCollection collection)
        {
            try
            {
                // TODO: Add update logic here

                return RedirectToAction(nameof(Index));
            }
            catch
            {
                return View();
            }
        }

        // GET: FileInfoResults/Delete/5
        public ActionResult Delete(int id)
        {
            return View();
        }

        // POST: FileInfoResults/Delete/5
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Delete(int id, IFormCollection collection)
        {
            try
            {
                // TODO: Add delete logic here

                return RedirectToAction(nameof(Index));
            }
            catch
            {
                return View();
            }
        }
    }
}
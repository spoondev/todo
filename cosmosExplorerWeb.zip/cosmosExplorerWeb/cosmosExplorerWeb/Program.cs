using System;
using Microsoft.AspNetCore.Hosting;
using Microsoft.Extensions.Hosting;
using DataAccessLayer;

namespace cosmosExplorerWeb
{
    public class Program
    {
        public static void Main(string[] args)
        {
            CreateHostBuilder(args).Build().Run();

            {

                string userTableSelection;

                Console.WriteLine("Azure Cosmos Table Samples");

                Console.WriteLine("Choose from the following tables to query");
                Console.WriteLine("1. FileInfo");
                Console.WriteLine("2. Employee");
                Console.WriteLine("3. AddMetadata");
                Console.WriteLine("4. AmbassadorPath");

                userTableSelection = Console.ReadLine();
                
                if (userTableSelection == "1")
                {
                    FileInfoQueries fileInfoQueries = new FileInfoQueries();
                    fileInfoQueries.RunFileInfoQueries().Wait();
                }
                //if (userTableSelection == "2")
                //{
                //    EmployeeQueries employeeQueries = new EmployeeQueries();
                //    employeeQueries.RunEmployeeQueries().Wait();
                //}
                //if (userTableSelection == "3")
                //{
                //    AddMetadataQueries addMetadataQueries = new AddMetadataQueries();
                //    addMetadataQueries.RunAddMetadataQueries().Wait();
                //}
                //if (userTableSelection == "4")
                //{
                //    AmbassadorPathQueries ambassadorPathQueries = new AmbassadorPathQueries();
                //    ambassadorPathQueries.RunAmbassadorPathQueries().Wait();
                //}

                Console.WriteLine();
                Console.WriteLine("Press any key to exit");
                Console.Read();
            }




        }

        public static IHostBuilder CreateHostBuilder(string[] args) =>
            Host.CreateDefaultBuilder(args)
                .ConfigureWebHostDefaults(webBuilder =>
                {
                    webBuilder.UseStartup<Startup>();
                });
    }


}



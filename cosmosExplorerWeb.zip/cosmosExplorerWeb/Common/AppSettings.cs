﻿using Microsoft.Extensions.Configuration;
//using Microsoft.Extensions.Configuration.Memory;


namespace DataAccessLayer
{

    public class AppSettings
    {
        public string StorageConnectionString { get; set; }

        public static AppSettings LoadAppSettings()
        {
            IConfigurationRoot configRoot = new ConfigurationBuilder()
                .AddJsonFile("Settings1.json")
                .Build();

            AppSettings appSettings = configRoot.Get<AppSettings>();
            return appSettings;
        }
    }
}
﻿using System;
using Microsoft.Azure.Cosmos.Table;
using System.Linq;
using System.Threading.Tasks;
using cosmosExplorerWeb.Models;

namespace DataAccessLayer
{
    public class FileInfoQueries
    {

        private readonly CloudConnection _cloudConnection;

        public FileInfoQueries()
        {
            _cloudConnection = new CloudConnection();
        }
        public async Task<CloudTable> RunFileInfoQueries()
        {

            CloudTable table = _cloudConnection.GetClient().GetTableReference("fileInfoHistory");

            Console.WriteLine(table);


            try
            {
                await FileInfoDataOperationsAsync(table);
                Console.WriteLine(table);
            }
            finally
            {

                Console.WriteLine("search complete");
            }

            return table;
        }


        private async Task FileInfoDataOperationsAsync(CloudTable table)
        {
            int partitionstringforselectall;
            //int rowstringforselectall;
            //string userSelection;
            //Int32 volumestringforselectall;

            partitionstringforselectall = int.Parse(Console.ReadLine());

            TableQuery<FileInfoModel> fileInfoWhere = new TableQuery<FileInfoModel>().Where
                (
                TableQuery.GenerateFilterCondition("PartitionKey", QueryComparisons.Equal, partitionstringforselectall.ToString())
                );

            var results = table.ExecuteQuery(fileInfoWhere);


            if (results.Any())
            {
                foreach (FileInfoModel fileInfo in results)
                {
                    results.ToString();
                }
            }

        }

    }
}
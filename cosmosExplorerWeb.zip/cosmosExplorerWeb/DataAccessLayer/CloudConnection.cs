﻿
using Common;
using Microsoft.Azure.Cosmos.Table;


namespace DataAccessLayer
{
    public class CloudConnection
    {
        public CloudTableClient GetClient()
        {
            string storageConnectionString = AppSettings.LoadAppSettings().StorageConnectionString;

            Microsoft.Azure.Cosmos.Table.CloudStorageAccount storageAccount = CloudStorageConnection.CreateStorageAccountFromConnectionString(storageConnectionString);

            CloudTableClient tableClient = storageAccount.CreateCloudTableClient(new TableClientConfiguration());

            return (tableClient);

        }
    }
}


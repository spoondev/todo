﻿using System;

using Microsoft.Azure.Cosmos;
using Microsoft.Azure.Cosmos.Table;

namespace cosmosExplorerWeb.Models
{
    public class FileInfoModel : TableEntity
    {
        public FileInfoModel()
        {
        }

        public FileInfoModel(string employeeID, string fileInfoID)
        {
            PartitionKey = employeeID;
            RowKey = fileInfoID;
        }

        public string FileName { get; set; }
        public string FileExtension { get; set; }
        public string Path { get; set; }
        public string ContainerPath { get; set; }
        public int ObjectTypeID { get; set; }
        public int AssignedEmployeeID { get; set; }
        public Int64 Size { get; set; }
        public DateTime CTime { get; set; }
        public DateTime MTime { get; set; }
        public DateTime ATime { get; set; }
        public DateTime ModifiedDate { get; set; }
        public DateTime CreatedDate { get; set; }
        public string ModifiedBy { get; set; }
        public string CreatedBy { get; set; }
        //public byte[] MetaHash { get; set; }
        public bool FraudFlag { get; set; }
        public bool IsDeleted { get; set; }
        public int ProtectionTypeID { get; set; }
        public int VolumeID { get; set; }
        public int OwnershipConfirmedTypeID { get; set; }
        public int ProtectionConfirmedTypeID { get; set; }

        internal static FeedIterator<T> GetItemQueryIterator<T>(QueryDefinition queryDefinition)
        {
            throw new NotImplementedException();
        }
    }

}
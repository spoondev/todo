﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.Azure.Cosmos;
using Microsoft.Azure.Cosmos.Table;

namespace cosmosExplorerWeb.Models

{
    public class FileInfoComplianceTypeModel : TableEntity
    {
        public FileInfoComplianceTypeModel()
        {
        }

        //public FileInfoComplianceTypeEntity()
        //{

        //}

        public Int64 FileInfoID { get; set; }
        public int ComplianceTypeId { get; set; }
        public DateTime ModifiedDate { get; set; }
        public DateTime CreatedDate { get; set; }
        public string ModifiedBy { get; set; }
        public string CreatedBy { get; set; }

        internal static FeedIterator<T> GetItemQueryIterator<T>(QueryDefinition queryDefinition)
        {
            throw new NotImplementedException();
        }
    }

}
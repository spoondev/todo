﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Text;

namespace cosmosExplorerWeb.Models
{
    public class FileInfoQueryModel
    {
        [Required]
        public string FileInfoQueryUserInput { get; set; }
    }
}

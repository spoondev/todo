﻿using cosmosExplorerWeb.Models;
using System;
using System.Collections.Generic;
using System.Text;

namespace Models
{
    public class FileInfoResultsModel
    {
        public IList<FileInfoModel> FileInfoModels { get; set; }
    }
}

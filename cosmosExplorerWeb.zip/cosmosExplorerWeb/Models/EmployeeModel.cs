﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.Azure.Cosmos;
using Microsoft.Azure.Cosmos.Table;

namespace cosmosExplorerWeb.Models

{
    public class EmployeeModel : TableEntity
    {
        public EmployeeModel()
        {
        }


        public EmployeeModel(string domainQualifiedUsername, string Rowkey)
        {
            PartitionKey = domainQualifiedUsername;
            //RowKey = RowKey;
        }

        public string BusinessArea { get; set; }
        public string CreatedBy { get; set; }
        public string Email { get; set; }
        public string EmployeeFirst { get; set; }
        public string EmployeeLast { get; set; }
        public int EmployeeNumber { get; set; }
        public bool Leaver { get; set; }
        public int ManagerID { get; set; }
        public string ModifiedBy { get; set; }
        public DateTime ModifiedDate { get; set; }
        public int UserRoleID { get; set; }


        internal static FeedIterator<T> GetItemQueryIterator<T>(QueryDefinition queryDefinition)
        {
            throw new NotImplementedException();
        }
    }

}
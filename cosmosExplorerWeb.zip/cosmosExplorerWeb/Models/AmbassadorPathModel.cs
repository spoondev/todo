﻿using System;
using Microsoft.Azure.Cosmos;
using Microsoft.Azure.Cosmos.Table;

namespace cosmosExplorerWeb.Models
{
    public class AmbassadorPathModel : TableEntity
    {
        public AmbassadorPathModel()
        {

        }
        //first few lines need a look at
        public AmbassadorPathModel(string EmployeeId, string Path)
        {
            PartitionKey = EmployeeId;
            RowKey = Path;
        }
        public Int64 AmbassadorPathId { get; set; }
        public int EmployeeManagerId { get; set; }
        public string AdGroup { get; set; }
        public string OpCo { get; set; }
        public bool FraudFolder { get; set; }
        public bool SecurityFolder { get; set; }
        public bool HrFolder { get; set; }
        public DateTime ModifiedDate { get; set; }
        public DateTime CreatedDate { get; set; }
        public string ModifiedBy { get; set; }
        public string CreatedBy { get; set; }

        internal static FeedIterator<T> GetItemQueryIterator<T>(QueryDefinition queryDefinition)

        {

            throw new NotImplementedException();

        }

    }



}

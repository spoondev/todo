using todo.Models;

namespace todo
{
    using System;
    using System.Collections.Generic;
    using System.Configuration;
    using System.Linq;
    using System.Linq.Expressions;
    using System.Threading.Tasks;
    using Microsoft.Azure.Cosmos;
    using Microsoft.Azure.Cosmos.Table;
    using todo.Services;

    public class CloudConnection
    {
        public CloudTableClient GetClient()
        {
            string storageConnectionString = AppSettings2.LoadAppSettings().StorageConnectionString;

            CloudStorageAccount storageAccount = Common.CreateStorageAccountFromConnectionString(storageConnectionString);

            CloudTableClient tableClient = storageAccount.CreateCloudTableClient(new TableClientConfiguration());

            return (tableClient);

        }


    }
}

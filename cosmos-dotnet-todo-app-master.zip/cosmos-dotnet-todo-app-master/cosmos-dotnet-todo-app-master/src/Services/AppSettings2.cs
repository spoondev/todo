﻿using Microsoft.Extensions.Configuration;
//using Microsoft.Extensions.Configuration.Memory;

namespace todo.Services
{
    public class AppSettings2
    {
        public string StorageConnectionString { get; set; }

        public static AppSettings2 LoadAppSettings()
        {
            IConfigurationRoot configRoot = new ConfigurationBuilder()
                .AddJsonFile("Settings1.json")
                .Build();

            AppSettings2 appSettings = configRoot.Get<AppSettings2>();
            return appSettings;
        }
    }
}
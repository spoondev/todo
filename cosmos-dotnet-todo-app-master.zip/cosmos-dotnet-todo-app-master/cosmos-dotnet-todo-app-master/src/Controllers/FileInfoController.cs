﻿namespace todo.Controllers
{
    using System.Net;
    using System.Threading.Tasks;
    using System.Web.Mvc;
    using Models;
    using Microsoft.Azure.Cosmos.Table;
    using System;
    using System.Linq;


    public class FileInfoController : Controller
    {

        private readonly CloudConnection _cloudConnection;

        public FileInfoController()
        {
            _cloudConnection = new CloudConnection();
        }
        public async Task RunFileInfoQueries()
        {

            CloudTable table = _cloudConnection.GetClient().GetTableReference("fileInfoHistory");

            Console.WriteLine(table);
        }

        [ActionName("Index")]
        public async Task<ActionResult> IndexAsync()
        {
            CloudTable table = _cloudConnection.GetClient().GetTableReference("addMetadataHistory");
            var items = await FileInfoItemService.GetOpenItemsAsync(table);
            return View(items);
        }
        
        [ActionName("Create")]
        public async Task<ActionResult> CreateAsync()
        {
            return View();
        }

        //[HttpPost]
        //[ActionName("Create")]
        //[ValidateAntiForgeryToken]
        //public async Task<ActionResult> CreateAsync([Bind(Include = "Id,Name,Description,Completed,Category")] TodoItem item)
        //{
        //    if (ModelState.IsValid)
        //    {
        //        await TodoItemService.CreateItemAsync(item);
        //        return RedirectToAction("Index");
        //    }

        //    return View(item);
        //}

        //[HttpPost]
        //[ActionName("Edit")]
        //[ValidateAntiForgeryToken]
        //public async Task<ActionResult> EditAsync([Bind(Include = "Id,Name,Description,Completed,Category")] TodoItem item)
        //{
        //    if (ModelState.IsValid)
        //    {
        //        await TodoItemService.UpdateItemAsync(item);
        //        return RedirectToAction("Index");
        //    }

        //    return View(item);
        //}

        //[ActionName("Edit")]
        //public async Task<ActionResult> EditAsync(string id, string category)
        //{
        //    if (id == null)
        //    {
        //        return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
        //    }

        //    TodoItem item = await TodoItemService.GetTodoItemAsync(id, category);
        //    if (item == null)
        //    {
        //        return HttpNotFound();
        //    }

        //    return View(item);
        //}

        //[ActionName("Delete")]
        //public async Task<ActionResult> DeleteAsync(string id, string category)
        //{
        //    if (id == null)
        //    {
        //        return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
        //    }

        //    TodoItem item = await TodoItemService.GetTodoItemAsync(id, category);
        //    if (item == null)
        //    {
        //        return HttpNotFound();
        //    }

        //    return View(item);
        //}

        //[HttpPost]
        //[ActionName("Delete")]
        //[ValidateAntiForgeryToken]
        //public async Task<ActionResult> DeleteConfirmedAsync([Bind(Include = "Id, Category")] string id, string category)
        //{
        //    await TodoItemService.DeleteItemAsync(id, category);
        //    return RedirectToAction("Index");
        //}

        //[ActionName("Details")]
        //public async Task<ActionResult> DetailsAsync(string id, string category)
        //{
        //    TodoItem item = await TodoItemService.GetTodoItemAsync(id, category);
        //    return View(item);
        //}
    }
}